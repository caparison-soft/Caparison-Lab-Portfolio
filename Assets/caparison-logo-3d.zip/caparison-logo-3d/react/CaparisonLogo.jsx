/**
 * Caparison Soft — 3D glass logo (React Three Fiber)
 *
 *   npm i three@^0.169 @react-three/fiber @react-three/drei
 *
 *   import CaparisonLogo from './CaparisonLogo';
 *   <CaparisonLogo src="/caparison_logo.glb" className="h-[480px]" />
 *
 * Put caparison_logo.glb in /public so the path resolves at runtime.
 * In Next.js, render it inside a client component ('use client').
 */

'use client';

import { Suspense, useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import * as THREE from 'three';

/* Studio softbox strips — same light rig as the Blender render: mostly
   black with two bright bands. Built on a canvas, no HDR to download. */
function useStudioStripEnv() {
  return useMemo(() => {
    const c = document.createElement('canvas');
    c.width = 1024; c.height = 512;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, 1024, 512);
    const g = ctx.createLinearGradient(0, 512, 0, 0);
    [
      [0.00, '#000000'], [0.17, '#000000'], [0.225, '#ffffff'], [0.28, '#000000'],
      [0.45, '#000000'], [0.505, '#ffffff'], [0.56, '#000000'],
      [0.74, '#000000'], [0.79, '#b4b4b4'], [0.845, '#000000'], [1.00, '#000000']
    ].forEach(([p, col]) => g.addColorStop(p, col));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 1024, 512);
    const tex = new THREE.CanvasTexture(c);
    tex.mapping = THREE.EquirectangularReflectionMapping;
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }, []);
}

function Logo({ src, autoRotate, rotateSpeed, fit, glass }) {
  const { scene } = useGLTF(src);
  const group = useRef();
  const env = useStudioStripEnv();
  const { scene: three } = useThree();
  three.environment = env;

  const model = useMemo(() => {
    const root = scene.clone(true);
    const material = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transmission: 1,
      thickness: 0.55,
      ior: 1.52,
      dispersion: 5,
      roughness: 0.015,
      metalness: 0,
      clearcoat: 1,
      clearcoatRoughness: 0,
      envMapIntensity: 1.3,
      ...glass
    });
    root.traverse(o => { if (o.isMesh) o.material = material; });

    const box = new THREE.Box3().setFromObject(root);
    const size = new THREE.Vector3(); box.getSize(size);
    const center = new THREE.Vector3(); box.getCenter(center);
    root.position.sub(center);
    root.scale.setScalar(fit / Math.max(size.x, size.y, size.z));
    return root;
  }, [scene, fit, glass]);

  const target = useRef({ x: 0, y: 0 });
  const spin = useRef(0);

  useFrame((state, dt) => {
    if (!group.current) return;
    const { x: px, y: py } = state.pointer;      // -1 … 1
    target.current.y = px * 0.35;
    target.current.x = -py * 0.22;
    if (autoRotate) spin.current += rotateSpeed * dt * 60;
    group.current.rotation.y += (target.current.y + spin.current - group.current.rotation.y) * 0.07;
    group.current.rotation.x += (target.current.x - group.current.rotation.x) * 0.07;
  });

  return <group ref={group}><primitive object={model} /></group>;
}

export default function CaparisonLogo({
  src = '/caparison_logo.glb',
  autoRotate = true,
  rotateSpeed = 0.0042,
  fit = 1.75,
  glass,
  className,
  style
}) {
  const reduce = typeof window !== 'undefined'
    && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  return (
    <Canvas
      className={className}
      style={style}
      dpr={[1, 2]}
      gl={{ antialias: true, alpha: true, toneMappingExposure: 1.15 }}
      camera={{ fov: 34, position: [0, 0, 4.1] }}
      frameloop="always"
    >
      <Suspense fallback={null}>
        <Logo
          src={src}
          autoRotate={autoRotate && !reduce}
          rotateSpeed={rotateSpeed}
          fit={fit}
          glass={glass}
        />
      </Suspense>
    </Canvas>
  );
}

useGLTF.preload('/caparison_logo.glb');
