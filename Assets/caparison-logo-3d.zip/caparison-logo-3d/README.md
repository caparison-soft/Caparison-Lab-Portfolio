# Caparison Soft — 3D glass logo

Drop-in package for putting the Caparison logo on a website as real-time 3D
transparent glass. No textures, no HDR download, one draw call.

```
caparison-logo-3d/
├─ caparison_logo.glb                      the mesh — 948 KB, 26,246 triangles
├─ caparison_logo_crystal.png              2000×2000 on off-white, hero still
├─ caparison_logo_crystal_transparent.png  2000×2000 transparent, static fallback
├─ vanilla/caparison-logo.js               framework-free ES module
└─ react/CaparisonLogo.jsx                 React Three Fiber component
```

## 1. Put the mesh where the browser can fetch it

Copy `caparison_logo.glb` into your public/static folder.

| Framework | Destination | URL at runtime |
|---|---|---|
| Next.js | `public/` | `/caparison_logo.glb` |
| Vite / CRA | `public/` | `/caparison_logo.glb` |
| Astro | `public/` | `/caparison_logo.glb` |
| Plain HTML | next to `index.html` | `./caparison_logo.glb` |

## 2a. React / Next.js

```bash
npm i three@^0.169 @react-three/fiber @react-three/drei
```

```jsx
import CaparisonLogo from '@/components/CaparisonLogo';

export default function Hero() {
  return (
    <div style={{ height: 480 }}>
      <CaparisonLogo src="/caparison_logo.glb" />
    </div>
  );
}
```

The canvas fills its parent, so **the parent needs a height** — that is the one
mistake worth watching for. In Next.js App Router the file already carries
`'use client'`.

Props: `src`, `autoRotate`, `rotateSpeed`, `fit`, `glass` (any
`MeshPhysicalMaterial` override), `className`, `style`.

## 2b. Plain HTML / any other stack

```bash
npm i three@^0.169
```

```html
<canvas id="logo" style="width:100%;height:480px"></canvas>

<script type="module">
  import { mountCaparisonLogo } from './vanilla/caparison-logo.js';
  mountCaparisonLogo(document.getElementById('logo'), {
    src: './caparison_logo.glb'
  });
</script>
```

Without a bundler, add an import map before the script so `three` resolves:

```html
<script type="importmap">
{ "imports": {
  "three": "https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js",
  "three/examples/jsm/": "https://cdn.jsdelivr.net/npm/three@0.169.0/examples/jsm/"
}}
</script>
```

Returns `{ setAutoRotate, material, dispose }`. Call `dispose()` when the
element is removed.

## 3. The material

Dispersion glass — clear crystal that splits light into rainbow on the edges.
Colour comes from the environment, not the mesh, so retuning is a one-line
change with no re-export from Blender.

```js
{
  transmission: 1,       // fully see-through
  thickness: 0.55,       // how far light bends inside
  ior: 1.52,             // real glass
  dispersion: 5,         // the rainbow; 0 = plain glass, 12 = heavy prism
  roughness: 0.015,      // 0 = polished, 0.18 = frosted
  metalness: 0,
  clearcoat: 1,
  envMapIntensity: 1.3   // overall brightness of reflections
}
```

`dispersion` needs **three r167 or newer** — on older versions the field is
ignored and you get plain glass, no error.

The rainbow only shows if the environment has hard bright-against-dark edges.
Both files build that environment on a canvas: black with two bright softbox
strips, the same rig as the Cycles render. Flatten it to an even grey and the
dispersion disappears — the light rig is half the look.

Frosted variant: `roughness: 0.18`, `thickness: 0.9`, `dispersion: 2`.
Chrome variant: `transmission: 0`, `metalness: 1`, `roughness: 0.05`.

## 4. Seeing page content through the glass

This is the one thing that does not work the way it looks like it should.

The canvas is transparent, so anything **around** the logo shows through
normally — text, background, other elements. But anything **behind** the logo
is not refracted. `transmission` samples only what three.js itself rendered;
your DOM is invisible to the shader. Put a headline behind the canvas and the
glass will show the environment map, not the headline.

To actually bend page content, that content has to be inside the 3D scene:

```js
mountCaparisonLogo(canvas, {
  src: '/caparison_logo.glb',
  backdrop: {
    color: '#F1F1EF',
    image: '/hero-bg.jpg',                     // optional
    draw: (ctx, w, h) => {                     // optional — paint anything
      ctx.textAlign = 'center';
      ctx.fillStyle = '#14161A';
      ctx.font = '700 210px Inter, sans-serif';
      ctx.fillText('CAPARISON', w / 2, 420);
    }
  }
});
```

The backdrop is drawn on a plane sized to fill the frame, so it reads as the
section background — and the glass refracts it properly. Hide the DOM copy of
whatever you moved in there, or the viewer sees it twice.

Rule of thumb: **static hero content → move it into `backdrop`. Live, scrolling
or interactive content → leave it in the DOM, beside the logo rather than
behind it.** Capturing a live DOM tree into a texture (html2canvas and friends)
is slow and breaks on fonts, video and cross-origin images; it is not worth it.

## 5. Before it ships

- **Transmission costs a second render pass.** On low-end phones, fall back to
  the chrome variant, or to `caparison_logo_crystal_transparent.png`.
- **Cap the pixel ratio at 2** — already set in both files. Full retina DPR
  triples the fragment work for no visible gain on a shape this simple.
- **The animation loop pauses off-screen** via `IntersectionObserver` in the
  vanilla build. In R3F, add `frameloop="demand"` or gate it yourself if the
  logo sits far down a long page.
- **Reduced motion is respected** — auto-rotate stays off when the OS asks for
  less movement. Pointer response still works.
- **Transparent canvas by default**, so the page background shows through. For
  a self-contained dark stage, pass `transparent: false` in the vanilla build.
- **Render the PNG first**, swap in the canvas on `logo:ready` — no layout
  shift, and no empty box if WebGL fails.
- **The glass reads best on a light ground** (`#F1F1EF` is what the stills
  use). On a dark page, raise `envMapIntensity` or the logo sinks into it.

## Source

Geometry rebuilt in Blender 5.2 from the original scan mesh (the scan was
~2M triangles across 33 shells, too noisy to read as glass). In Cycles the
dispersion is three Glass BSDFs stacked at IOR 1.462 / 1.520 / 1.588, filtered
to red, green and blue — Blender 5.2 has no dispersion socket, so the split is
done by hand. `MeshPhysicalMaterial.dispersion` approximates the same effect in
one line, and shares the light rig, so the still and the live logo read as the
same object.
